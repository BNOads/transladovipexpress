<?php 

	$nomepass = $_GET['nomepass'];
	$nomeempr = $_GET['nomeempr'];
	$radio = $_GET['radio'];
	$nome = $_GET['nome'];
	$zap = $_GET['zap'];
	$unidade = $_GET['unidade'];
	$mensagem = $_GET['mensagem'];
	$placa = $_GET["placa"];
	$cpf = $_GET["cpf"];
	$local = $_GET["local"];
	$localfinal = $_GET["localfinal"];
	$data = $_GET["data"];
	$quant = $_GET["quant"];
	$metodo = $_GET["metodo"];

//Monta o Corpo da Mensagem

	//====================================================

	$impr_conteudo = "*RECIBO DE TÁXI AEROPORTO DE CONFINS* <br>*Passageiro*: $nomepass <br>";

	$impr_conteudo .= "*Empresa*: $nomeempr <br>";

	$impr_conteudo .= "*Motorista*: $nome <br>";

	$impr_conteudo .= "*Unidade do táxi*: $unidade <br>";

	$impr_conteudo .= "*Placa*: $placa <br>";

	$impr_conteudo .= "*CPF/CNPJ do Motorista*: $cpf <br>";

	$impr_conteudo .= "*Órgão Gerenciador*: $radio <br>";

	$impr_conteudo .= "*Data Da Corrida*: $data <br>";

	$impr_conteudo .= "*Ponto de partida*: $local <br>";

	$impr_conteudo .= "*Local De Destino*: $localfinal <br>";


	$impr_conteudo .= "*Detalhamento da corrida*: $mensagem <br>";
	
	$impr_conteudo .= "*Pagamento*: $metodo <br>";
	$impr_conteudo .= "*TOTAL A PAGAR*: *$quant* <br>";
		

	//====================================================



//Monta o Corpo da Mensagem

	//====================================================

	$email_conteudo = "*RECIBO DE TÁXI AEROPORTO DE CONFINS* %0A%0A*Passageiro*: $nomepass %0A";

	$email_conteudo .= "*Empresa*: $nomeempr %0A%0A";

	$email_conteudo .= "*Motorista*: $nome %0A";

	$email_conteudo .= "*Unidade do táxi*: $unidade %0A";

	$email_conteudo .= "*Placa*: $placa %0A";

	$email_conteudo .= "*CPF/CNPJ do Motorista*: $cpf %0A";

	$email_conteudo .= "*Órgão Gerenciador*: $radio %0A%0A";

	$email_conteudo .= "*Data Da Corrida*: $data %0A";

	$email_conteudo .= "*Ponto de partida*: $local %0A";

	$email_conteudo .= "*Local De Destino*: $localfinal %0A%0A";


	$email_conteudo .= "*Detalhamento da corrida*: $mensagem %0A%0A";
			$email_conteudo .= "*Pagamento*: $metodo %0A";

	$email_conteudo .= "*TOTAL A PAGAR*: *$quant* %0A%0A%0A";

	$email_conteudo .= "Confira a resolução do DER*: https://drive.google.com/file/d/1kUdXLs4RZJ6Y5eVeYMF1DTnFyfjs5ahT/view?usp=sharing %0A%0A";

		$email_conteudo .= "%0A%0A Obrigado pela Preferência.";


	//====================================================
	

 ?>
<!DOCTYPE HTML>

<html lang="pt-BR">

	<head>

		<title>Tabela Táxi Aeroporto 2024</title>



		<meta charset="UTF-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>

		<link rel="stylesheet" href="../assets/css/main.css"/>

		<meta http-equiv="X-UA-Compatible" content="IE=Edge"/>

<meta name="theme-color" content="#362929">

<meta name="apple-mobile-web-app-status-bar-style" content="#362929">

<meta property="og:locale" content="_ptBR"><script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-98388796-1"></script>

<script>

  window.dataLayer = window.dataLayer || [];

  function gtag(){dataLayer.push(arguments);}

  gtag('js', new Date());



  gtag('config', 'UA-98388796-1');

</script>



<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-flexdatalist/2.3.0/jquery.flexdatalist.min.js" integrity="sha512-JEX6Es4Dhu4vQWWA+vVBNJzwejdpqeGeii0sfiWJbBlAfFzkeAy6WOxPYA4HEVeCHwAPa+8pDZQt8rLKDDGHgw==" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-flexdatalist/2.3.0/jquery.flexdatalist.min.css" integrity="sha512-feX1WY95JHQ//uffCG42xy0PofA6DAZSEgIQMMOmRBbSmmOoz/J52azXXLM3kYa9EkQ5PlOHFFCgqpnPJ1oYpg==" crossorigin="anonymous" />

<link rel="shortcut icon" href="icon2.png" type="image/x-icon"/>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.6.0/css/all.min.css" integrity="sha256-wX/yv3XrMHL9ho8i2z4rFw6B6cKKtxFiBuB2S+CRlmw=" crossorigin="anonymous"/>

<link rel="manifest" href="manifest/manifest.json">

<meta name="mobile-web-app-capable" content="yes">

    <link rel="icon" sizes="192x192" href="icon2.png">

    <meta name="theme-color" content="#09545e">





    <!-- Add to homescreen for Safari on iOS -->

    <meta name="apple-mobile-web-app-capable" content="yes">

    <meta name="apple-mobile-web-app-title" content="Tabela Táxi do Aeroporto 2024">

    <meta name="apple-mobile-web-app-status-bar-style" content="#09545e">

    <link rel="apple-touch-icon-precomposed" href="icon2.png">
 <!-- <meta http-equiv="refresh" content="2; URL='https://api.whatsapp.com/send?phone=55<?php echo $zap;?>&text=<?php echo $email_conteudo;?>'"/> -->


</head><body>

<center><a style="background-color: green;" class='btn-a button'  href="https://api.whatsapp.com/send?phone=55<?php echo $zap;?>&text=<?php echo $email_conteudo;?>">Whatsapp</a>


<a style="background-color: red;" class='btn-a button' href="#" onclick="window.print();" >Imprimir</a>
</center>

<center><a class='btn-a button'  href="index.html">Voltar</a>
<center>
<?php echo $impr_conteudo;?></center>

</body>
