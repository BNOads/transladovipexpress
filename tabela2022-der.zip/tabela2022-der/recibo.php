<?php 	

//$forma1 = $_GET['forma'];


//$meio = explode(" ",$forma1);

//$metodo = $meio[0];
//$metodo2 = $meio[1];
//$metodo3 = $meio[3];

$locrecibo = $_GET['recibo'];
$city = $_GET['local'];

$loc = number_format($locrecibo, 0, '.', '');
//$porcentagem = $loc * ($metodo2 / 100);
//$valorcomtaxa = $porcentagem + $loc;
//$valorcomtaxa = number_format($valorcomtaxa, 0, '.', '');

 ?>

<html>

	<head>

		<title>Formulario</title>

		<meta charset="utf-8" />

		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />

		<link rel="shortcut icon" href="icone.png" type="image/x-icon"/>

		<script src="assets/js/main.js"></script>

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

		<link rel="stylesheet" href="assets/css/main.css" />

			<link rel=”canonical” href=”www.transladovipexpress.com.br/contato.php” />

		<meta name="description" content=" Quer Conhecer a melhor empresa de Táxi em Confins? Consulte a Translado Vip Express. Menores preços do mercado.">

		<meta name="keywords" content="Translado Vip Express, Traslado Vip Express, Confins, Táxi, Taxi, Táxi em Confins, Transfer, Táxi no Aeroporto de Confins, Transfer de Confins para Ouro Preto, Transfer de Confins Para Inhotim">

		<meta name="author" content="JpConfins">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-wX/yv3XrMHL9ho8i2z4rFw6B6cKKtxFiBuB2S+CRlmw=" crossorigin="anonymous"/>

<!-- GTranslate: https://gtranslate.io/ -->

<div id="google_translate_element2"></div>

<script type="text/javascript">

function googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: 'pt',autoDisplay: false}, 'google_translate_element2');}

</script><script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"></script>





<!-- Google Tag Manager -->

<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':

new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],

j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=

'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);

})(window,document,'script','dataLayer','GTM-WHWNDGH');</script>

<!-- End Google Tag Manager -->

<!-- Chrome, Firefox OS and Opera -->

<meta name="theme-color" content="#362929">

<!-- iOS Safari -->

<meta name="apple-mobile-web-app-status-bar-style" content="#362929">



<meta property="og:locale" content="_ptBR">

	<meta property="og:title" content="Táxi em Confins">

	<meta property="og:description" content="Táxi no Aeroporto de Confins">

	<meta property="og:type" content="website" />

	<meta property="og:site_name" content="Translado Vip Express">



	</head>

	



	<body>



<!-- Google Tag Manager (noscript) -->

<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WHWNDGH"

height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<!-- End Google Tag Manager (noscript) -->



		

		<style type="text/css">

			[type="date"] {

  background:#fff url(https://cdn1.iconfinder.com/data/icons/cc_mono_icon_set/blacks/16x16/calendar_2.png)  97% 50% no-repeat ;

}

[type="date"]::-webkit-inner-spin-button {

  display: none;

    text-decoration-color: black;

  color: black;

}

[type="date"]::-webkit-calendar-picker-indicator {

  opacity: 0;

  text-decoration-color: black;

  color: black;

}

		</style>



            

	

<!DOCTYPE HTML>

<html>

	<head>

		<meta charset="utf-8" />

		

		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />

		<link rel="stylesheet" href="../assets/css/main.css" />



		<link rel="shortcut icon" href="icon2.png" type="image/x-icon"/>	

		<script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>

		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.0/css/all.css" integrity="sha384-aOkxzJ5uQz7WBObEZcHvV5JvRW3TUc2rNPA7pe3AwnsUohiw1Vj2Rgx2KSOkF5+h" crossorigin="anonymous">

  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>







	</head>

	

	<body>



	

<header id="header" style="background-color: #3266CC;">



	<div class="inner">



	

	<center><h1 href="index.html" title="Translado Vip Express" style="color: red; margin-top: 0.6em;">Recibo de Taxi  </h1></center>





		<nav id="nav"></a></nav></div></header>

			<section id="main">

			<div class="inner" >



			<!-- Formulário -->

			<section id="main" style="margin-top: -8em;">

				<div class="inner animated fadeIn">



 
		<section>

			<div class="inner">				

				<form action="envio.php" name="formulario" method="GET">

					
	<p>

<div class="6u$ 12u$(xsmall)"><fieldset style="margin-right:40%;"><label for="local"><legend><h4 style="color:#09545e;">Nome do Passageiro:</h4></legend></fieldset></label>

							<input type="text" name="nomepass" id="nomepass" value="" placeholder="Nome do Passageiro:" />

						</div>

					</p>

<p>

<div class="6u$ 12u$(xsmall)"><fieldset style="margin-right:40%;"><label for="local"><legend><h4 style="color:#09545e;">Nome da Empresa:</h4></legend></fieldset></label>

							<input type="text" name="nomeempr" id="nomeempr" value="" placeholder="Nome da Empresa:" />

						</div>

					</p>

				<h3 style="color: red;">--------------------------------------</h3>



					<p><div class="6u$ 12u$(xsmall)"><fieldset style="margin-right: 100%;"><label for="nome1"><legend><h4 style="color:#09545e;">Motorista:</h4></legend></fieldset></label>



							<input type="text" name="nome" id="nome1" value="" placeholder="Nome" required/>

					</p>

			</div>

			<input type="hidden" name="metodo" value="<?php echo $metodo?>">

				<p>

<div class="6u$ 12u$(xsmall)"><fieldset style="margin-right: 100%;"><label for="unidade"><legend><h4 style="color:#09545e;">Unidade:</h4></legend></fieldset></label>

							<input type="text" name="unidade" id="unidade" value="" placeholder="Unidade" />

						</div>

					</p>



									<p>

<div class="6u$ 12u$(xsmall)"><fieldset style="margin-right: 100%;"><label for="placa"><legend><h4 style="color:#09545e;">placa:</h4></legend></fieldset></label>

							<input type="text" name="placa" id="placa" value="" placeholder="placa" />

						</div>

					</p>





														<p>

<div class="6u$ 12u$(xsmall)"><fieldset style="margin-right: 100%;"><label for="cpf"><legend><h4 style="color:#09545e;">CPF/CNPJ:</h4></legend></fieldset></label>

							<input type="text" name="cpf" id="cpf" value="" placeholder="CPF/CNPJ" />

						</div>

					</p>

	

														<p>




					</p>


					<p>

<div class="6u$ 12u$(xsmall)"><fieldset style="margin-right:40%;"><label for="local"><legend><h4 style="color:#09545e;">Ponto de partida:</h4></legend></fieldset></label>

							<input type="text" name="local" id="local" value="" placeholder="Local de partida" />

						</div>

					</p>



					<p>

<div class="6u$ 12u$(xsmall)"><fieldset style="margin-right: 50%;"><label for="local"><legend><h4 style="color:#09545e;">Destino Final:</h4></legend></fieldset></label>

<input type="text"  readonly = "readonly" name="localfinal" id="localfinal"  value="<?php echo $city;?>"/>

						</div>

					</p>



					<p>

<div class="6u$ 12u$(xsmall)"><fieldset style="margin-right: 40%;"><label for="quant"><legend><h4 style="color:#09545e;">Valor da Corrida:</h4></legend></fieldset></label>

<input type="text" name="quant" id="quant" readonly = "readonly"   value="R$<?php echo $loc;?>,00"/>

						</div>

					</p>





	

		

	<p>

		<div class="6u$ 12u$(xsmall)"><fieldset style="margin-right: 50%;"><label for="date"><legend><h4 style="color:#09545e;">Data da corrida:</h4></legend></fieldset></label>

<input type="text" name="data" id="data"   readonly = "readonly"   value="<?php echo date('d/m/y');?>"/>

  				

		</div>

	</p>

	<p>

		<div class="6u$ 12u$(xsmall)"><fieldset><label for="message"><legend><h4 style="color:#09545e;">Informações adicionais:</h4></legend></fieldset>



		<textarea name="mensagem" id="message" placeholder="Informações Adicionais" rows="5"></textarea>

		</div>

	</p>




<div class="6u$ 12u$(xsmall)"><fieldset style="margin-right: 100%;"><label for="cpf"><legend><h4 style="color:#09545e;">Orgão Gerenciador</h4></legend></fieldset></label>

	<input type="radio" id="radio1" name="radio"  value="TRANS-CONFINS"  checked>

							<label for="radio1">TRANS-CONFINS</label>


							
							<input type="radio" id="radio" name="radio"  value="SEINFRA" >

							<label for="radio">SEINFRA</label>



						


							<input type="radio" id="radio2" name="radio"  value="TRANS-LAGO
							"  >

							<label for="radio2">TRANS-LAGO</label>

						</div>




	



			<p><fieldset style="margin-right: 12%;"><label for="email1"><legend><center><h4 style="color:#09545e;">Enviar para (Whatsapp):</h4></legend></center>

 </fieldset></label><div class="6u$ 12u$(xsmall)">	

							<input type="number" name="zap" id="zap" value="" placeholder="Numero" required/>

						</div>

					</p>



	<p>









         	<center> <input type="submit" name="BTEnvia" style="background-color: red; margin-bottom: 1em;" class="button special" value="Enviar">
          <a class='btn-a button'  href="https://transladovipexpress.com.br/tabela2022/index.html">Voltar</a>





     </p>

		</div>

		</form>










			<!-- Scripts -->

			<script src="assets/js/skel.min.js"></script>

	</body>

</html>