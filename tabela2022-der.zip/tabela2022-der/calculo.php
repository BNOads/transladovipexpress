<?php 

if (isset($_GET['BTEnvia'])) {

$forma = $_GET['forma'];


$desconto = explode(" ",$forma);

$desconto1 = $desconto[0]; //Nome
$desconto2 = $desconto[1]; // Valor
	

//$loc = number_format($locrecibo, 0, '.', '');
//$porcentagem = $loc * ($metodo2 / 100);
//$valorcomtaxa = $porcentagem + $loc;
//$valorcomtaxa = number_format($valorcomtaxa, 0, '.', '');


$variavel = $_GET['loc'];



$partes = explode(" ",$variavel);



$total=$partes[0]; //Valor

$loc1=$partes[1]; //Cidade

$loc2=$partes[2]; //Cidade

$loc3=$partes[3]; //Cidade

$loc4=$partes[4]; //Cidade

$loc5=$partes[5]; //Cidade

$loc6=$partes[6]; //Cidade







$city=$loc1." ".$loc2." ".$loc3." ".$loc4." ".$loc5." ".$loc6; // 



$varn = str_replace(',', '.', $total);

$loc = ($varn * $desconto2);

$loc = number_format($loc, 0, '.', '');




}

   ?>



<!DOCTYPE HTML>

<html>

	<head>
<style>
          

           
            .inline-monospace {
                font-family: monospace;
            }

            .intro {
                border-bottom: 1px solid #d4d4d4;
                padding-bottom: 20px;
            }

            
            .intro .code-snippet {
            }

            .native-gallery-item {
                margin: 20px 0;
                border-bottom: 1px solid #d4d4d4;
                display: flex;
                flex-flow: row wrap;
            }

            .native-gallery-item:last-of-type {
                border-bottom: 0;
            }

            .native-gallery-item h2 {
                margin-bottom: 21px;
                width: 100%;
                flex: 1 100%;
            }

            .native-gallery-rendering-sample {
                flex: 1;
            }

            .native-gallery-code-section {
                flex: 1;
                display: flex;
            }

            .native-gallery-code-snippet {
                flex: 1;
            }

            .native-gallery-code-block {
                resize: none;
                width: 100%;
                height: 300px;
                font-family: monospace;
                font-size: 0.8em;
                outline: none;
                background: #f0f0f0;
                padding: 10px;
                position: relative;
                left: -20px;
            }
            
            .code-snippet .native-gallery-code-block {
	            position: relative;
	            left: 0;
            }

            .native-gallery-copy-btn {
                font-size: 1em;
                padding: 3px;
                border: 1px solid #888;
                background-color: #999;
                cursor: pointer;
                position: relative;
                top: -29px;
                left: -20px;
                color: #fff;
            }
            
            .code-snippet .native-gallery-copy-btn {
	            top: -30px;
	            left: 0;
            }

            .native-gallery-copy-btn:hover {
                background-color: #fff;
            }
            
            #haircut {
	            margin-top: 0;
            }




* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}
.mySlides {display: none}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}
        </style>   


		<meta charset="utf-8" />

		

		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />

		<link rel="stylesheet" href="../assets/css/main.css" />



		<link rel="shortcut icon" href="icon2.png" type="image/x-icon"/>	

		<script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>

		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.0/css/all.css" integrity="sha384-aOkxzJ5uQz7WBObEZcHvV5JvRW3TUc2rNPA7pe3AwnsUohiw1Vj2Rgx2KSOkF5+h" crossorigin="anonymous">

  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>







	</head>

	

	<body>


	

<header id="header" style="background-color: #3266CC;">



	<div class="inner">



	

	<center><h1 href="index.html" title="Translado Vip Express" style="color: #fff; margin-top: 0.8em;"><?php echo $desconto1;?>  </h1></center>





		<nav id="nav"></a></nav></div></header>
			<section id="main">

<center>
<iframe style="color: #fff; margin-top: -3.5em;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3757.8228076143982!2d-43.96973605287214!3d-19.634871734616905!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xa6631c0e742453%3A0x9cb0e3528a7a1983!2sAeroporto%20Internacional%20de%20Belo%20Horizonte%20(Aeroporto%20Tancredo%20Neves)!5e0!3m2!1spt-BR!2sbr!4v1704140078926!5m2!1spt-BR!2sbr" width="400" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</center>

							<center><a href="https://www.google.com/maps/place/<?php echo $city;?>" style="background-color: green; margin-bottom: 1em;" target="_blank" class="button special" >Abrir no Mapa</a>

		<!-- Main -->

	<section id="main">

			<div class="inner" style="margin-top: -10em;"> 

				<header class="major special">	<center>
<h2>  			

	<?php 				echo "</h2>	<h1  color:  #3459b8; font-size: 2em;'><center> <br></h1><h1  color:  #3459b8;'><center> <br>" . $city; 

							echo "<h1 style='color: #082b85; font-size: 2em;'>R$ $loc,00</h2></center></h1>";	

							 ?>


</center>


<!--
<center><div class="6u$ 12u$(xsmall)"><fieldset><label for="cpf"><legend><h4 style="color:#09545e;">Selecione a forma de pagamento</h4></legend></fieldset></label> -->



<form action="recibo.php" method="GET"> 

	<input type="hidden" name="recibo" value="<?php echo$loc; ?>">
		<input type="hidden" name="local" value="<?php echo$city; ?>">


		<center><a class='btn-a button' href="index.html">Voltar</a>	
  	<input type="submit" style="background-color: red; margin-top: -4em;" class="button special" value="Emitir recibo">
  	   <div align="center"/> 		<center><img src="dermg.png" style="width:  8em;  color: blue;"><img src="cnf.png" style="width:  7em;  color: blue;"></center>

</center>

<!--
		<input type="radio" id="1" name="forma"  value="Credito 4.8" checked>

		<label style="text-transform: capitalize;" for="1">Crédito</label>



		<input type="radio" id="2" name="forma"  value="Debito 2.85">

		<label style="text-transform: capitalize;" for="2">Débito</label>



		<input type="radio" id="3" name="forma"  value="PIX/Dinheiro 0">

		<label style="text-transform: capitalize;" for="3">PIX/Dinheiro</label>

-->


   </div></center>

					
			

  

<br>
</form>
							
 <article class='native-gallery-item' style="margin-top: -6em;">
            <section class='native-gallery-rendering-sample'>
                <div class="an-native-ad img-left" style="display:block;font-family:Helvetica Neue, Helvetica, Arial, sans-serif;">
<center> 
<div class="slideshow-container">

<div class="mySlides fade">
	    <a href="https://api.whatsapp.com/send/?phone=5531992154314&text=Ol%C3%A1!%20Vim%20da%20tabela%20de%20t%C3%A1xi%20e%20gostaria%20de%20saber%20mais%20sobre%20a%20condi%C3%A7%C3%A3o%20especial" target="_blank">
  <img src="placeholder.jpg" style="width:200%">
  <div class="text">Barbearia Fabio Herculano</div></a>
</div>

<div class="mySlides fade">
	    <a href="https://api.whatsapp.com/send?phone=553189262251&text=Ol%C3%A1!%20Vim%20da%20tabela%20de%20t%C3%A1xi%20e%20gostaria%20de%20saber%20mais%20sobre%20a%20condi%C3%A7%C3%A3o%20especial" target="_blank">

  <img src="8.jpg" style="width:200%">
  <div class="text">Pizzaria Canoa de minas</div></a>
</div>

<div class="mySlides fade">
        <a href="https://api.whatsapp.com/send?phone=5531997336631&text=Ol%C3%A1!%20Vim%20da%20tabela%20e%20gostaria%20de%20saber%20sobre%20a%20promo%C3%A7%C3%A3o%20para%20bebidas" target="_blank">

  <img src="7.jpeg" style="width:200%">
  <div class="text">Casa mendonça</div></a>
</div>

<div class="mySlides fade">
        <a href="https://api.whatsapp.com/send?phone=5537999874585&text=Ol%C3%A1!%20Vim%20da%20tabela%20e%20gostaria%20de%20vender%20meu%20carro" target="_blank">

  <img src="5.jpeg" style="width:200%">
  <div class="text">Marlon veículos</div></a>
</div>


</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
    <span class="dot" onclick="currentSlide(3)"></span> 
      <span class="dot" onclick="currentSlide(4)"></span> 


</div>
</center>
    </a>

</div>
            </section>
            <section class='native-gallery-code-section'>
                <div class='native-gallery-code-snippet'>
               
                  
                </div></center>
            </section>
        </article>
     <script>
let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 4000); // Change image every 2 seconds
}

</script>


								</header>

			</div>

	</section>



			<!-- Scripts -->

			<script src="assets/js/skel.min.js"></script>

	</body>

</html>